// src/admin/index.ts

// function export
export * from './api/deleteUser.api'
export * from './api/getAllUsers.api'
export * from './api/updateUserRole.api'