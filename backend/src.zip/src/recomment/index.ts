// src/recomment/index.ts

export * from "./functions/recommentFromProvince.api";