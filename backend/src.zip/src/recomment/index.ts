// src/recomment/index.ts

export * from "./api/recommentFromProvince.api";