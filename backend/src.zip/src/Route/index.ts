// src/Route/index.ts

export * from './functions/getRoute.api';
