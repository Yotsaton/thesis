// src/Route/index.ts

export * from './api/getRoute.api';
